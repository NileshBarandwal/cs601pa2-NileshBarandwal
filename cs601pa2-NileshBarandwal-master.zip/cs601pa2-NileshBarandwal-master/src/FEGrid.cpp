//acknowledgement: cs294-73 colella@eecs.berkeley.edu
#include <cstdio>   
#include <cmath>    
#include <cstring>  
#include <cassert>  
#include <vector>
#include <fstream>
#include<iostream>
#include<iomanip>
#include<limits>
#include "Node.h"   
#include "Element.h"
#include "FEGrid.h"

FEGrid::FEGrid(): m_numInteriorNodes(0)
{
}

FEGrid::FEGrid(const std::string& a_nodeFileName, const std::string& a_elementFileName) {
  ifstream nodes(a_nodeFileName.c_str());
  int ncount;
  nodes>>ncount;

  m_nodes.resize(ncount);
  m_numInteriorNodes= 0;
  for(int i=0; i<ncount; i++)
    {
      int vertex;
      std::string tmp[DIM];
      double x[DIM];
      bool isInterior=true;
      nodes>>vertex>>tmp[0]>>tmp[1];
      x[0]=atof(tmp[0].c_str());
      x[1]=atof(tmp[1].c_str());

      if(((tmp[0].compare("0.60000"))==0) || ((tmp[1].compare("0.40000"))==0) || (x[0] == 0) || (x[1] == 0)) {
	isInterior = false;
	//printf("Node ID:%d is on Boundary\n",vertex);
	}
	else
  		m_numInteriorNodes++;
      
      vertex--;
      m_nodes[vertex] = Node(x,vertex, isInterior);
    }
 
  ifstream elements(a_elementFileName.c_str());
  int ncell;
  elements>>ncell;
  int vert[VERTICES];
  m_elements.resize(ncell);
  for(int i=0; i<ncell; i++)
    {
      int cellID;
      elements>>cellID>>vert[0]>>vert[1]>>vert[2];
      vert[0]--; vert[1]--; vert[2]--;
      cellID--;
      m_elements[cellID] = Element(vert);
    }
}

//returns the gradient of shape functions N1 N2 N3.
void FEGrid::gradient(double a_gradient[DIM],
		      const int& a_eltNumber, 
		      const int& a_nodeNumber) const
{
  const Element& e = m_elements[a_eltNumber];
  const Node& n=m_nodes[e[a_nodeNumber]];
  //assert(n.isInterior()); //make sure that you are computing it for interior node only.
  double xbase[DIM];
  n.getPosition(xbase);
  double dx[VERTICES-1][DIM];
  for (int ivert = 0;ivert < VERTICES-1; ivert++)
    {
      int otherNodeNumber = e[(a_nodeNumber + ivert+1)%VERTICES];
      m_nodes[otherNodeNumber].getPosition(dx[ivert]);
      for (int idir = 0;idir < DIM;idir++)
        {
          dx[ivert][idir] -=xbase[idir];
        }
    }        
  
  // WARNING: the following calculation is correct for triangles in 2D *only*.
  double det = dx[0][0]*dx[1][1] - dx[1][0]*dx[0][1];
  
  a_gradient[0] = (-(dx[1][1] - dx[0][1])/det);
  a_gradient[1] = (-(dx[1][0] - dx[0][0])/det);

}

double FEGrid::elementArea(const int& a_eltNumber) const
{
  const Element& e = m_elements[a_eltNumber];
  const Node& n=m_nodes[e[0]];
  double xbase[DIM];
  n.getPosition(xbase);
  double dx[VERTICES-1][DIM];
  for (int ivert = 1;ivert < VERTICES; ivert++)
    {
      int otherNodeNumber = e[ivert];
      m_nodes[otherNodeNumber].getPosition(dx[ivert-1]);
      for (int idir = 0;idir < DIM;idir++)
        {
          dx[ivert-1][idir] -=xbase[idir];
        }
    }        
  
  // WARNING: the following calculation is correct for triangles in 2D *only*.
  double area = fabs(dx[0][0]*dx[1][1] - dx[1][0]*dx[0][1])/2;
  return area;
}

const Node& FEGrid::getNode(const int& a_eltNumber,const int& a_localNodeNumber) const
{
  return m_nodes[m_elements[a_eltNumber][a_localNodeNumber]];
}

int FEGrid::getNumElts() const
{
  return m_elements.size();
}

int FEGrid::getNumNodes() const
{
  return m_nodes.size();
}

int FEGrid::getNumInteriorNodes() const
{
  return m_numInteriorNodes;
}

const Element& FEGrid::element(int i) const
{
  return m_elements[i];
}
const Node& FEGrid::node(int i) const
{
  return m_nodes[i];
}
