//This is CS601: PA2. The questions are indicated in lines having comments bearing the question number. Fill in your answers in place. 
//When you are done filling in your answers, the code must be compilable. Code with syntax errors receive Zero. Do not change any other lines other than what is indicated in the question.
#include "FEGrid.h"
#include<vector>
#include<string>
#include<cmath>
#include <iostream>
#include<iomanip>
#include<fstream>
#define K 30


using namespace std;

int main(int argc, char** argv) {
  if(argc != 2)
    {
      cout << "this program takes just one argument that is the common name prefix of .node and .elem files. (Note: do not give the file extension) ";
      return 1;
    }
  string prefix(argv[1]);
  string nodeFile = prefix+".node";
  string eleFile  = prefix+".elem";
  string q3Answer, q4AnswerA, q4AnswerB;

  FEGrid grid(nodeFile, eleFile);

  //get the total number of nodes and interior nodes 
  int numInteriorNodes = grid.getNumInteriorNodes();
  int numNodes = grid.getNumNodes();

  //Global stiffness matrix stores the Kij values of all interior nodes.
  //The globalMatrixIndex array stores the index of the interior node in the global matrix
  int* globalMatrixIndex = (int*)malloc(sizeof(int)*numNodes);
  int interiorNodeIndex=0;
  for(int i=0;i<numNodes;i++) {
  	const Node& n = grid.node(i);
	if(n.isInterior())
		globalMatrixIndex[i]=interiorNodeIndex++;
	else
		globalMatrixIndex[i]=-1;
  }
  double *globalK=(double *)malloc(sizeof(double)*numInteriorNodes*numInteriorNodes);
  memset(globalK, 0, sizeof(double)*numInteriorNodes*numInteriorNodes);
  double kij[VERTICES*VERTICES]; //for storing B^T * C * B
  double kijpartial[VERTICES*VERTICES]; //for storing B^T * C
  double cMatrix[DIM*2]={K, 0, 0, K};

  //Poisson operator over the grid elements
  for(int i=0;i<grid.getNumElts();i++) {
	Element e=grid.element(i);
	//first count the number of interior nodes in the element e.
	std::vector<int> elementInteriorNodeID;
	for(int j=0;j<VERTICES;j++) {
		const Node& n= grid.getNode(i, j);
		if(n.isInterior()) {
			//storing nodeLocal number of the interior node of the element.
			elementInteriorNodeID.push_back(j); 
		}
	}
	int numInteriorNodesOfElement = elementInteriorNodeID.size();

	//allocate storage for gradient of shape functions for each interior node/vertex of the element 
	double* bMatrixTrans=(double *)malloc(sizeof(double)*numInteriorNodesOfElement*DIM);
	//get gradient of the shape functions for all interior nodes of the element.
	for(int j=0;j<numInteriorNodesOfElement;j++)		
			grid.gradient(bMatrixTrans+j*DIM, i, elementInteriorNodeID[j]);
#ifndef CBLAS_DGEMM
	//compute B^T * C (3x2 * 2x2) OR (2x2 * 2x2) or (1x2 * 2x2)
	for(int m=0;m<numInteriorNodesOfElement;m++) {
		for(int n=0;n<DIM;n++) {
  			kijpartial[m*DIM+n]=0.;
			for(int r=0;r<DIM;r++)
				kijpartial[m*DIM+n] = kijpartial[m*DIM+n]+bMatrixTrans[m*DIM+r] * cMatrix[r*DIM+n];
		}
	}
#else
	//https://www.intel.com/content/www/us/en/develop/documentation/mkl-tutorial-c/top/multiplying-matrices-using-dgemm.html
	/*Q1: if you had access to the CBLAS library routine cblas_dgemm, you can rewrite lines 70-76 by a single line that calls the cblas_dgemm routine. 
	 *Write how you would achieve the equivalentof 70-76 using cblas_dgemm routine. Make sure that you do not have syntax errors. You must make a call to the BLAS routine (i.e. not write your answer in double quotes).
	 */
#endif
	//Q2: Write routine to dump kijpartial in a file called kijdump.bin here (in binary format)

	//creating B from B^T	
	double *bMatrix=(double *)malloc(sizeof(double)*DIM*numInteriorNodesOfElement);
	for(int m=0;m<DIM;m++)
		for(int n=0;n<numInteriorNodesOfElement;n++)
			bMatrix[m*numInteriorNodesOfElement+n]=bMatrixTrans[n*DIM+m];
			
	free(bMatrixTrans);

	//multiplying with B.
	for(int m=0;m<numInteriorNodesOfElement;m++) {
		for(int n=0;n<numInteriorNodesOfElement;n++) {
  			kij[m*numInteriorNodesOfElement+n]=0.;
			for(int r=0;r<DIM;r++)
				kij[m*numInteriorNodesOfElement+n] = kij[m*numInteriorNodesOfElement+n] + kijpartial[m*DIM+r] * bMatrix[r*numInteriorNodesOfElement+n];
		}
  	}

	free(bMatrix);


  	//Insert element matrix contents into global Matrix
	for(int m=0;m<numInteriorNodesOfElement;m++) {
			int nodeGlobalNumber = e[elementInteriorNodeID[m]];
			assert(globalMatrixIndex[nodeGlobalNumber] !=-1);
			int rowNumber = globalMatrixIndex[nodeGlobalNumber];
			for(int n=0;n<numInteriorNodesOfElement;n++) {
				int colNumber = globalMatrixIndex[e[elementInteriorNodeID[n]]];
				globalK[rowNumber*numInteriorNodes+colNumber] +=kij[m*numInteriorNodesOfElement+n];
		}
	}	
  }

	/*Q3: What is the structure of the global matrix globalK? Choose your option from: 1) Tridiagonal 2) Diagonal 3) BiDiagonal 4) Banded 5) Upper Hessenberg 6) Lower Hessenberg
	 * Write your answer (as a string that exactly matches one of the options above.) in the space provided below.*/
  	q3Answer="ANSWER TO Q3 GOES HERE";
	  

	/*Q4: What is the lower bandwidth (PART A) and upper bandwidth (PART B) of the matrix represented in globalK when this program is run as: ./pa4 fine ?*/
  	q4AnswerA="ANSWER TO Q4 (part A) GOES HERE";
  	q4AnswerB="ANSWER TO Q4 (part B) GOES HERE";

	cout<<q3Answer<<endl;
	cout<<"Lower Bandwidth: "<<q4AnswerA<<endl;
	cout<<"Upper Bandwidth: "<<q4AnswerB<<endl;

#ifdef DEBUG
			
  	//write the global matrix into a file for visualization.
	ofstream myoutputfile;
	myoutputfile.open("GlobalKMatrixFile.txt");
	for(int m=0;m<numInteriorNodes;m++) {
		for(int n=0;n<numInteriorNodes;n++){
				myoutputfile<<globalK[m*numInteriorNodes+n];
				if(n!=numInteriorNodes-1)
					myoutputfile<<" ";
				else
					myoutputfile<<"\n";
		}
	}
#endif
	
	//Jacobi solver goes here.

  
  return 0;
  
}
